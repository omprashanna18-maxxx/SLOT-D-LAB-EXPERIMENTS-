text = input("Enter a sequence of characters: ")

if len(text) >= 2 and text == text[::-1]:
    print("Pattern detected: Palindrome")
elif text.isdigit():
    print("Pattern detected: Numeric sequence")
elif text.isalpha():
    print("Pattern detected: Alphabetic sequence")
else:
    print("Pattern detected: Mixed sequence")
