rules = {
    "flu": ["fever", "cough"],
    "cold": ["sneezing", "runny_nose"]
}

facts = set(input("Enter symptoms (space-separated): ").lower().split())
goal = input("Enter condition to check: ").lower()

if goal in rules and all(item in facts for item in rules[goal]):
    print(goal, "is supported by the given symptoms.")
else:
    print(goal, "cannot be confirmed from the given symptoms.")
