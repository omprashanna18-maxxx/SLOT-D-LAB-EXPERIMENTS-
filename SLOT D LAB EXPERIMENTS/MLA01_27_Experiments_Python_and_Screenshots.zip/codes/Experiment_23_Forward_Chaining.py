facts = set(input("Enter known facts (space-separated): ").lower().split())

if "computer_on" in facts and "power" in facts:
    facts.add("system_running")
if "system_running" in facts and "network" in facts:
    facts.add("internet_available")

print("Derived facts:")
for fact in sorted(facts):
    print(fact)
