from sklearn.tree import DecisionTreeClassifier

# Features: [income in thousands, credit score]
X = [[20, 500], [25, 520], [60, 700], [80, 750],
     [30, 550], [90, 800]]
y = ["Reject", "Reject", "Approve", "Approve",
     "Reject", "Approve"]

model = DecisionTreeClassifier(random_state=0)
model.fit(X, y)

income = int(input("Enter income (thousands): "))
credit = int(input("Enter credit score: "))
print("Loan decision:", model.predict([[income, credit]])[0])
