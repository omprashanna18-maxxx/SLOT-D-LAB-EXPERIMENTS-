planets = {
    "mercury": "Closest planet to the Sun",
    "venus": "Hottest planet",
    "earth": "Known to support life",
    "mars": "Known as the Red Planet",
    "jupiter": "Largest planet",
    "saturn": "Known for its rings",
    "uranus": "Rotates on its side",
    "neptune": "Farthest planet from the Sun"
}

name = input("Enter planet name: ").lower()
print(planets.get(name, "Planet not found."))
