fever = input("Do you have fever? (yes/no): ").lower()
cough = input("Do you have cough? (yes/no): ").lower()
cold = input("Do you have a runny nose? (yes/no): ").lower()

if fever == "yes" and cough == "yes":
    print("Possible condition: flu-like illness. Seek medical advice.")
elif cold == "yes" and fever == "no":
    print("Possible condition: common cold.")
else:
    print("Insufficient information. Consult a healthcare professional.")
