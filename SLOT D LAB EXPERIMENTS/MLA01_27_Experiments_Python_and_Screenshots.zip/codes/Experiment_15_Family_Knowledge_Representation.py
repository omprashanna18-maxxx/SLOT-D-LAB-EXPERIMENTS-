parent = {
    "Ravi": ["Anu", "Kiran"],
    "Anu": ["Maya"],
    "Kiran": ["Arun"]
}

person1 = input("Enter first person: ")
person2 = input("Enter second person: ")

if person2 in parent.get(person1, []):
    print(person1, "is a parent of", person2)
elif person1 in parent.get(person2, []):
    print(person2, "is a parent of", person1)
else:
    print("No direct parent relationship found.")
