import heapq

graph = {"A": [("B", 1), ("C", 4)],
         "B": [("D", 2)], "C": [("D", 1)], "D": []}
h = {"A": 3, "B": 2, "C": 1, "D": 0}

start = input("Enter start node: ").upper()
goal = input("Enter goal node: ").upper()
pq = [(h[start], 0, start, [start])]
best = {}

while pq:
    f, g, node, path = heapq.heappop(pq)
    if node in best and best[node] <= g:
        continue
    best[node] = g
    if node == goal:
        print("Optimal path:", " -> ".join(path))
        print("Total cost:", g)
        break
    for nxt, cost in graph[node]:
        new_g = g + cost
        if nxt not in best or new_g < best[nxt]:
            heapq.heappush(pq, (new_g + h[nxt], new_g, nxt, path + [nxt]))
else:
    print("No path found.")
