import heapq

graph = {}
n = int(input("Enter number of nodes: "))
for _ in range(n):
    graph[input("Enter node: ")] = []

e = int(input("Enter number of edges: "))
for _ in range(e):
    u, v, w = input("Enter edge (u v cost): ").split()
    w = int(w)
    graph[u].append((v, w))
    graph[v].append((u, w))

start = input("Enter start node: ")
goal = input("Enter goal node: ")
pq = [(0, start, [start])]
best = {}

while pq:
    cost, node, path = heapq.heappop(pq)
    if node in best and best[node] <= cost:
        continue
    best[node] = cost
    if node == goal:
        print("Least-cost path:", " -> ".join(path))
        print("Total cost:", cost)
        break
    for nxt, weight in graph[node]:
        if nxt not in best:
            heapq.heappush(pq, (cost + weight, nxt, path + [nxt]))
else:
    print("No path found.")
