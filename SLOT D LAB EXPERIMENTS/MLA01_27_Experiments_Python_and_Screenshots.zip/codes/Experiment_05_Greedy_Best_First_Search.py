import heapq

graph = {"A": ["B", "C"], "B": ["D", "E"],
         "C": ["F"], "D": [], "E": [], "F": []}
h = {"A": 5, "B": 3, "C": 2, "D": 4, "E": 1, "F": 0}

start = input("Enter start node: ").upper()
goal = input("Enter goal node: ").upper()
pq = [(h[start], start, [start])]
visited = set()

while pq:
    _, node, path = heapq.heappop(pq)
    if node in visited:
        continue
    visited.add(node)
    if node == goal:
        print("Greedy path:", " -> ".join(path))
        break
    for nxt in graph[node]:
        if nxt not in visited:
            heapq.heappush(pq, (h[nxt], nxt, path + [nxt]))
else:
    print("No path found.")
