sentence = input("Enter a sentence: ")
vowels = "aeiouAEIOU"
found = [ch for ch in sentence if ch in vowels]

print("Vowels:", " ".join(found))
print("Total vowels:", len(found))
