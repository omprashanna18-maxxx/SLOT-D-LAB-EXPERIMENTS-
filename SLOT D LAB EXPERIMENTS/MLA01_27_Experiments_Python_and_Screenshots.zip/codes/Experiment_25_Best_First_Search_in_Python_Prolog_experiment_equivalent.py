import heapq

graph = {"A": ["B", "C"], "B": ["D"], "C": ["D"], "D": []}
heuristic = {"A": 3, "B": 2, "C": 1, "D": 0}

start = input("Enter start node: ").upper()
goal = input("Enter goal node: ").upper()
queue = [(heuristic[start], start, [start])]
visited = set()

while queue:
    _, node, path = heapq.heappop(queue)
    if node in visited:
        continue
    visited.add(node)
    if node == goal:
        print("Best path:", " -> ".join(path))
        break
    for nxt in graph[node]:
        if nxt not in visited:
            heapq.heappush(queue, (heuristic[nxt], nxt, path + [nxt]))
else:
    print("No path found.")
