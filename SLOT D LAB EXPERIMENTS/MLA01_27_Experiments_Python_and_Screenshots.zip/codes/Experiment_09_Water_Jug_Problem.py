from collections import deque

a = int(input("Enter capacity of jug A: "))
b = int(input("Enter capacity of jug B: "))
target = int(input("Enter target amount: "))

q = deque([((0, 0), [])])
visited = set()

while q:
    (x, y), path = q.popleft()
    if (x, y) in visited:
        continue
    visited.add((x, y))
    path = path + [(x, y)]
    if x == target or y == target:
        print("Steps:")
        for state in path:
            print(state)
        break
    states = [(a, y), (x, b), (0, y), (x, 0),
              (x - min(x, b-y), y + min(x, b-y)),
              (x + min(y, a-x), y - min(y, a-x))]
    for state in states:
        if state not in visited:
            q.append((state, path))
else:
    print("Target cannot be measured.")
