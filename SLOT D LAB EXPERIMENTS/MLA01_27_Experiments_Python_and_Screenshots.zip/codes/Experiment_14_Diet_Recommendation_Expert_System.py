age = int(input("Enter age: "))
bmi = float(input("Enter BMI: "))
condition = input("Enter condition (none/diabetes): ").lower()

if condition == "diabetes":
    diet = "Consult a qualified dietitian for a diabetes-friendly plan."
elif bmi < 18.5:
    diet = "Balanced meals with adequate nutrition; consult a dietitian."
elif bmi < 25:
    diet = "Maintain a varied, balanced diet."
else:
    diet = "Choose balanced meals and discuss needs with a dietitian."

print("Age:", age)
print("Diet recommendation:", diet)
