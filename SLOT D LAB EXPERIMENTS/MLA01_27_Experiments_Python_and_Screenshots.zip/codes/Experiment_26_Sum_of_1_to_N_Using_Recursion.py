def sum_n(n):
    if n == 0:
        return 0
    return n + sum_n(n - 1)

n = int(input("Enter a positive integer: "))
print("Sum from 1 to", n, "=", sum_n(n))
