from sklearn.neural_network import MLPClassifier

# Simple sample dataset: [study hours, attendance]
X = [[1, 50], [2, 55], [3, 60], [5, 75],
     [6, 80], [7, 90], [8, 95], [4, 65]]
y = [0, 0, 0, 1, 1, 1, 1, 0]

model = MLPClassifier(hidden_layer_sizes=(5,), max_iter=3000,
                      random_state=1)
model.fit(X, y)

hours = float(input("Enter study hours: "))
attendance = float(input("Enter attendance percentage: "))
prediction = model.predict([[hours, attendance]])[0]
print("Prediction:", "Good performance" if prediction else "Needs improvement")
