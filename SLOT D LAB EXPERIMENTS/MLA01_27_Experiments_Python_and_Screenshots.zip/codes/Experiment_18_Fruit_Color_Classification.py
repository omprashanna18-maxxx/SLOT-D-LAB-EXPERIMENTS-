color = input("Enter fruit color: ").lower()

if color == "yellow":
    print("Possible fruit: Banana")
elif color == "red":
    print("Possible fruit: Apple or Cherry")
elif color == "orange":
    print("Possible fruit: Orange")
elif color == "green":
    print("Possible fruit: Green apple")
else:
    print("Fruit not identified.")
