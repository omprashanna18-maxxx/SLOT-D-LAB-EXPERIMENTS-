monkey = input("Monkey position (door/center): ").lower()
box = input("Box position (door/center): ").lower()
banana = input("Is banana hanging high? (yes/no): ").lower()

if monkey == "door" and box == "center":
    print("1. Monkey walks to the box.")
    print("2. Monkey pushes the box below the banana.")
    print("3. Monkey climbs the box.")
    print("4. Monkey takes the banana.")
elif monkey == "center" and box == "center" and banana == "yes":
    print("1. Monkey climbs the box.")
    print("2. Monkey takes the banana.")
else:
    print("Move the box below the banana, then climb and take it.")
