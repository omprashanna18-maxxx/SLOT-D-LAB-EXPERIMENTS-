def alphabeta(depth, node, alpha, beta, maximizing, values):
    if depth == 2:
        return values[node]
    if maximizing:
        best = float("-inf")
        for child in (node * 2, node * 2 + 1):
            best = max(best, alphabeta(depth + 1, child, alpha, beta,
                                       False, values))
            alpha = max(alpha, best)
            if beta <= alpha:
                break
        return best
    best = float("inf")
    for child in (node * 2, node * 2 + 1):
        best = min(best, alphabeta(depth + 1, child, alpha, beta,
                                   True, values))
        beta = min(beta, best)
        if beta <= alpha:
            break
    return best

values = list(map(int, input("Enter 4 leaf values: ").split()))
if len(values) == 4:
    print("Optimal value:", alphabeta(0, 0, float("-inf"),
                                      float("inf"), True, values))
else:
    print("Enter exactly 4 values.")
