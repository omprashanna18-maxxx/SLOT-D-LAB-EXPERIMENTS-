def minimax(depth, node, maximizing, values):
    if depth == 2:
        return values[node]
    left = minimax(depth + 1, node * 2, not maximizing, values)
    right = minimax(depth + 1, node * 2 + 1, not maximizing, values)
    return max(left, right) if maximizing else min(left, right)

values = list(map(int, input("Enter 4 leaf values: ").split()))
if len(values) != 4:
    print("Please enter exactly 4 values.")
else:
    result = minimax(0, 0, True, values)
    print("Best value using Minimax:", result)
