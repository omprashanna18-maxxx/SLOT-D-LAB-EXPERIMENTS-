import heapq

graph = {"A": ["B", "C"], "B": ["D", "E"],
         "C": ["F"], "D": [], "E": [], "F": []}
heuristic = {"A": 5, "B": 3, "C": 2, "D": 4, "E": 1, "F": 0}

start = input("Enter start node (A-F): ").upper()
goal = input("Enter goal node (A-F): ").upper()
pq = [(heuristic[start], start, [start])]
visited = set()

while pq:
    _, node, path = heapq.heappop(pq)
    if node in visited:
        continue
    visited.add(node)
    if node == goal:
        print("Path:", " -> ".join(path))
        break
    for nxt in graph[node]:
        if nxt not in visited:
            heapq.heappush(pq, (heuristic[nxt], nxt, path + [nxt]))
else:
    print("No path found.")
