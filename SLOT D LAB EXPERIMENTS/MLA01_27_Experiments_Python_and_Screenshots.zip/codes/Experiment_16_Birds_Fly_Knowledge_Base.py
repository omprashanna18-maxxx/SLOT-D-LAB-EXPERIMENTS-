birds = {"sparrow", "pigeon", "parrot", "eagle"}
flightless = {"ostrich", "penguin"}

animal = input("Enter a bird: ").lower()

if animal in flightless:
    print(animal, "cannot fly.")
elif animal in birds:
    print(animal, "can fly.")
else:
    print("Bird information not available.")
