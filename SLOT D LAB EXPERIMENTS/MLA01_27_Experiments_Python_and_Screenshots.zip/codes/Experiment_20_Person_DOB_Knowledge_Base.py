people = {
    "Om": "15-08-2008",
    "Vishal": "12-03-2008",
    "Yuvan": "20-11-2007"
}

name = input("Enter person's name: ")
dob = people.get(name)

if dob:
    print("Date of birth:", dob)
else:
    print("Person not found.")
